﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace ara_2
{
    public partial class vpisanoBesediloButton : Form
    {
        public vpisanoBesediloButton()
        {
            InitializeComponent();
        }

        [DllImport(@"algoritem.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr sifriraj([MarshalAs(UnmanagedType.LPStr)] string abeceda, [MarshalAs(UnmanagedType.LPStr)] string sporocilo, [MarshalAs(UnmanagedType.LPStr)] string kljuc);

        [DllImport(@"algoritem.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr desifriraj([MarshalAs(UnmanagedType.LPStr)] string abeceda, [MarshalAs(UnmanagedType.LPStr)] string sporocilo, [MarshalAs(UnmanagedType.LPStr)] string kljuc);

        string abeceda = "pgcenbqozrslaftmdviwkuyxh";

      
        string abc = "";
        private void naloziAbecedoButton_Click(object sender, EventArgs e)
        {
            int stej = 0;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text|*.txt";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new
                StreamReader(ofd.FileName);
                abc = sr.ReadToEnd();
                abc.Replace(" ", string.Empty);
                foreach (char c in abc)
                {
                    if (c != ' ')
                    {
                        abeceda += c;
                        stej++;
                    }
                }
                sr.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (besediloTextBox.Text != String.Empty && kljucTextBox.Text != String.Empty)
            {
                string resitev = (Marshal.PtrToStringAnsi(sifriraj(abeceda, besediloTextBox.Text.ToLower(), kljucTextBox.Text.ToLower())));
                string koncna = "";
                foreach (char c in resitev)
                {
                    if (c != ' ')
                    {
                        koncna += c;
                    }
                }
                resitveTextBox.Text = koncna;
            }
            else
                MessageBox.Show("Vnesi besedilo in geslo!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string resitev = (Marshal.PtrToStringAnsi(desifriraj(abeceda, resitveTextBox.Text, kljucTextBox.Text.ToLower())));
            string koncna = "";
            foreach (char c in resitev)
            {
                if (c != ' ')
                {
                    koncna += c;
                }
            }
            besediloTextBox.Text = koncna;
        }

    }
}
