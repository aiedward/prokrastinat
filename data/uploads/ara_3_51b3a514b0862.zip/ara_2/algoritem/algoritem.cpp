#include <iostream>
#include <string>
#include <sstream>
using namespace std;

char getCrka(int pozicija)
{
	char crka;
	switch(pozicija){
	case 0:
		crka = 'A';
		break;
	case 1:
		crka = 'D';
		break;
	case 2:
		crka = 'F';
		break;
	case 3:
		crka = 'G';
		break;
	case 4:
		crka = 'X';
		break;
	}
	return crka;
}

extern "C" __declspec (dllexport) const char* sifriraj(const char* abeceda, const char* sporocilo, const char* kljuc);
const char* sifriraj(const char* abeceda, const char* sporocilo, const char* kljuc)
{
	string sSporocilo = (string)sporocilo;
	string sKljuc = (string)kljuc;

	string izhod = "";
	char polje[5][5];
	int stej = 0;
	//NASTAVI MATRIKO GLEDE NA ABECEDO
	for(int i = 0; i < 5; i++)
	{
		for(int j = 0; j < 5; j++)
		{	
			polje[i][j] = abeceda[stej];
			stej++;

		}
	}

	//GLEDE NA ABECEDO DOBIMO GESLO
	string skupnoGeslo = "";
	for(int k = 0; k<sSporocilo.length(); k++)
	{
		if(sSporocilo[k] == 'j')
		{
			sSporocilo[k] = 'i';
		}

		for(int i = 0; i < 5; i++)
		{
			for(int j = 0; j < 5; j++)
			{	
				if(sSporocilo[k] == polje[i][j]){
					skupnoGeslo += getCrka(i);
					skupnoGeslo += getCrka(j);
				}
			}
		}
	}

	int rows = 0;
	int deli = skupnoGeslo.length() / sKljuc.length();
	rows = deli;
	if(skupnoGeslo.length() % sKljuc.length() != 0)
	{
		rows++;
	}

	//2.MATRIKA, GLEDE NA KLJUC
	char** polje2 = new char*[sKljuc.length()];
	int stevec = 0;
	for(int i = 0; i < rows; i++)
	{
		polje2[i] = new char[sKljuc.length()];
		for(int j = 0; j < sKljuc.length(); j++)
		{
			if(stevec <= (skupnoGeslo.length() - 1))
			{
				polje2[i][j] = skupnoGeslo[stevec];
				stevec++;
			}
			else
			{
				polje2[i][j] = ' ';
				stevec++;
			}
		}
	}

	//KLJUC PO ABECEDI
	char vmesni;
	//BUBBLE SORT
	for(int i = 0; i < sKljuc.length(); i++)
	{
		for(int j = 0; j < (sKljuc.length() - 1); j++)
		{
			if(sKljuc[j] > sKljuc[j+1])
			{
				vmesni = sKljuc[j];
				sKljuc[j] = sKljuc[j+1];
				sKljuc[j+1] = vmesni;

				for(int k = 0; k < rows; k++)
				{
					vmesni = polje2[k][j];
					polje2[k][j] = polje2[k][j+1];
					polje2[k][j+1] = vmesni;
				}

			}
		}
	}

	//IZPISEMO PO STOLPCIH OD ZGORAJ NAVZDOL
	for(int i = 0; i < sKljuc.length(); i++)
    {
		for(int j  = 0; j < rows; j++)
        {
			stringstream stream;
			stream << polje2[j][i];
			izhod.append(stream.str());
        }
    }
	

	char* vrni = new char[izhod.length() +1];
	for(int i = 0; i < izhod.length(); i++)
	{
		vrni[i] = izhod[i];
	}

	vrni[izhod.length()] = '\0';
	return vrni;
}


extern "C" __declspec (dllexport) const char* desifriraj(const char* abeceda, const char* sporocilo, const char* kljuc);
const char* desifriraj(const char* abeceda, const char* sporocilo, const char* kljuc)
{
	string izhod ="";
	char* vrni = new char[izhod.length() +1];
	for(int i = 0; i < izhod.length(); i++)
	{
		vrni[i] = izhod[i];
	}

	vrni[izhod.length()] = '\0';
	return vrni;
}





